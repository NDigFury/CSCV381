package edu.arizona.cast.nikkidiguardi.glucose

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import edu.arizona.cast.nikkidiguardi.glucose.databinding.FragmentGlucoseBinding
import java.util.*

class GlucoseDetailFragment : Fragment() {

    private lateinit var glucose: Glucose
    private var _binding: FragmentGlucoseBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "Cannot access binding because it is null. Is the view visible?"
        }
    var date:Date = GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
        Calendar.getInstance().get(Calendar.MONTH),
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH)).time

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // date button shall display the current date
        binding.date.setText(date.toString())

        glucose = Glucose(
            date = Date(),
            fast = 0,
            bfast = 0,
            lunch = 0,
            dinner = 0
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding =
            FragmentGlucoseBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.apply {
            binding.dinnerInput.addTextChangedListener(object : TextWatcher{
                override fun afterTextChanged(s: Editable) {}
                override fun beforeTextChanged(s: CharSequence?,
                                               start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    if(binding.fastInput.text.toString().isNotEmpty()&&
                            binding.bfastInput.text.toString().isNotEmpty()&&
                            binding.lunchInput.text.toString().isNotEmpty()&&
                            binding.dinnerInput.text.toString().isNotEmpty()){
                        glucose.copy(
                            fast = (binding.fastInput.text.toString()).toInt(),
                            bfast = (binding.bfastInput.text.toString()).toInt(),
                            lunch = (binding.lunchInput.text.toString()).toInt(),
                            dinner = (binding.dinnerInput.text.toString()).toInt()
                        )
                        binding.status.visibility = View.VISIBLE
                        reading()
                    }
                }
            })
        }
        binding.clear.setOnClickListener {
            reset()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun reset() {
        binding.fastInput.text.clear()
        binding.bfastInput.text.clear()
        binding.lunchInput.text.clear()
        binding.dinnerInput.text.clear()
        binding.status.text = " "
        binding.status.visibility = View.GONE
    }
    private fun reading() {
        val glucoseViewModel: GlucoseViewModel by viewModels()
        val f = (binding.fastInput.text.toString()).toInt()
        val b = (binding.bfastInput.text.toString()).toInt()
        val l = (binding.lunchInput.text.toString()).toInt()
        val d = (binding.dinnerInput.text.toString()).toInt()
        val s = glucoseViewModel.formula(f,b,l,d)
        if (s.contains("Abnormal") or s.contains("Hypoglycemic")){
            binding.status.setTextColor(16)
        }
        binding.status.text = s
    }
}