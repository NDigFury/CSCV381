package edu.arizona.cast.nikkidiguardi.glucose
import androidx.lifecycle.ViewModel
import java.util.*


class GlucoseViewModel() : ViewModel() {
    val glucoses = mutableListOf<Glucose>()
    init {
        listings()
    }
    val calendar = GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
        Calendar.getInstance().get(Calendar.MONTH),
        Calendar.getInstance().get(Calendar.DAY_OF_MONTH))

    private fun listings() {
        for (i in 0..99) {
            val glucoseObject = Glucose(
                calendar.time, (60..180).random(), (60..180).random(),
                (60..180).random(), (60..180).random()
            )
            calendar.add(Calendar.DATE, -1)
            glucoses.add(glucoseObject)
        }
    }
    fun formula(f: Int, b: Int, l: Int, d: Int) : String {
        var ftxt = ""
        var btxt = ""
        var ltxt = ""
        var dtxt = ""
        if (f > 70 && f < 99) {
            ftxt = "Normal"
        } else if (f < 71) {
            ftxt = "Hypoglycemic"
        }

        if (b > 140) {
            btxt = "Abnormal"
        } else if (b < 71) {
            btxt = "Hypoglycemic"
        }

        if (l > 140) {
            ltxt = "Abnormal"
        } else if (l < 71) {
            ltxt = "Hypoglycemic"
        }

        if (d > 140) {
            dtxt = "Abnormal"
        } else if (d < 71) {
            dtxt = "Hypoglycemic"
        }

        else {
            ftxt = "Abnormal"
            btxt = "Normal"
            ltxt = "Normal"
            dtxt = "Normal"
        }
        var status = calendar.toString()
        status += "\n Fasting: "
        status += ftxt + "\n Breakfast: "
        status += btxt + "\n Lunch: "
        status += ltxt + "\n Dinner: " + dtxt
        return status
    }

}
