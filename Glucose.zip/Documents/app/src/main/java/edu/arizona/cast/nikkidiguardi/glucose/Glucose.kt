package edu.arizona.cast.nikkidiguardi.glucose

import java.util.*

data class Glucose(var date:Date = GregorianCalendar(Calendar.getInstance().get(Calendar.YEAR),
    Calendar.getInstance().get(Calendar.MONTH),
    Calendar.getInstance().get(Calendar.DAY_OF_MONTH)).time,
                   var fast:Int = -1,
                   var bfast:Int = -1,
                   var lunch:Int = -1,
                   var dinner:Int = -1,
)