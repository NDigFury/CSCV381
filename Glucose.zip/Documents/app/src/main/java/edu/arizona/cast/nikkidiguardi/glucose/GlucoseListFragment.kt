package edu.arizona.cast.nikkidiguardi.glucose

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import edu.arizona.cast.nikkidiguardi.glucose.databinding.GlucoseListBinding

private const val TAG = "GlucoseListFragment"

class GlucoseListFragment : Fragment() {
    private var _binding: GlucoseListBinding? = null
    private val binding
        get() = checkNotNull(_binding) {
            "Cannot access binding because it is null. Is the view visible?"
        }
    private val glucoseViewModel: GlucoseViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "Total readings: ${glucoseViewModel.glucoses.size}")
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = GlucoseListBinding.inflate(inflater, container, false)
        binding.glucoseRecyclerView.layoutManager = LinearLayoutManager(context)
        val gluc = glucoseViewModel.glucoses
        val adapter = GlucoseListAdapter(gluc)
        binding.glucoseRecyclerView.adapter = adapter
        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}